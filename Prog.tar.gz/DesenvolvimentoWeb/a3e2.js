//	Matheus de Lima Piovani #7563901
//	Caio Joanoni #7563770
//	Lucas Lucafo #7978251

function aluno(vNome,vID,vMedia)
{
	this.nome=vNome;
	this.ID=vID;
	this.Media=vMedia;
}
var alunos = [];
alunos[0] = new aluno ("Matheus",7563901,5.0);
alunos[1] = new aluno ("Caio",7563770,3.5);
alunos[2] = new aluno ("Lucas",7978251,2.2);
alunos[3] = new aluno ("Batata",4,9.98);
alunos[4] = new aluno ("Bixao",11111112,0.1);

function ex_media()
{
	var m = 0.0;
	for(var i=0;i<5;i++)
		m+=alunos[i].Media;
	document.write(m/5);
}