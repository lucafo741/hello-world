function busca(){
	var titulo = document.getElementById("query");
	var lugardotitulo = document.getElementsByTagName("h1");
	lugardotitulo[0].innerHTML=titulo.value;
	lugardotitulo[2].innerHTML=titulo.value;
}