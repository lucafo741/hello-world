$(document).ready(function()
{
	$('#bt').click(function() {
		var nome = $('#nome').val();
		var patt=/[A-Z,a-z]+/;
		if(!patt.test(nome))
		{
			$('#nome').css("border-color","red");
			alert("Digite um nome válido!");
		}
		else
		{
			$('#nome').css("border-color","green");
		}
		var nasc = $('#nascimento').val();
		patt = /^(\d{2})(\/)(\d{2})(\/)(\d{4})$/;
		var anoint = parseInt(nasc.substring(6,10));
		if(!patt.test(nasc))
		{
			$('#nascimento').css("border-color","red");
			alert("Digite uma data valida!");
		}
		else if(anoint>1996||anoint<1895)
		{
			$('#nascimento').css("border-color","red");
			if(anoint==1500)
			{
				alert("Voce é o Brasil!");
			}
			else
			{
				alert("voce é muito novo ou muito velho!");
			}
		}
		else
		{
			$('#nascimento').css("border-color","green");
		}
		var email = $('#email').val();
		patt = /\w+@\w+(\.)\w+/;
		if(!patt.test(email))
		{
			$('#email').css("border-color","red");
			alert("Digite um email válido!");
		}
		else
		{
			$('#email').css("border-color","green");
		}
		if($("#aceitar").is(":unchecked"))
		{
			alert("Você deve aceitar os nossos termos marcando a checkbox!");
		}
	}); 
});
