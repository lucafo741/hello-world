$(document).ready(function(){
	$("#button").click(function(){

		var x;
		x = Model.getProperty();
		x++;
		Model.setProperty(x);
	});
});	