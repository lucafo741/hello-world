var Model = {
	property: 0,
	getProperty: function(){
		return this.property;
	},
	setProperty: function(value){
		this.property = value;
		$(Model).triggerHandler('change');
	}

};