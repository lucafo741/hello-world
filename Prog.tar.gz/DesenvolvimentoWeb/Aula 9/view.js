$(Model).on('change',function(){
	$('#p').html(Model.getProperty());
});