function validar_id(){
	var ID = document.getElementById("id").value;
	var patt=/[A-Z]{1}[a-z]+_\d\d/;
	console.log(patt.test(ID));
	var res = ID.search(patt);
	if(!patt.test(ID) || res!=0){
		alert("ID inválido");
	}
}

function validar_leg(){
	var LEG = document.getElementById("legenda").value;
	var patt = /[a-z,A-Z,\s]{1,10}/;
	var patt2 =/[a-z,A-Z,\s]{11}/;
	if(!patt.test(LEG) || patt2.test(LEG)){
		alert("Legenda inválida");
	}

}

function validar_lin(){
	var LIN = document.getElementById("qlin").value;
	var n = parseInt(LIN);
	if(n<1 || n>10 || !n){
		alert("Quantidade de linhas inválida");
	}
}

function validar_col(){
	var COL = document.getElementById("qcol").value;
	var n = parseInt(COL);
	if(n<1 || n>10 || !n){
		alert("Quantidade de colunas inválida");
	}
}

function tabela(){
	
	var lin = document.getElementById("qlin").value;
	var col = document.getElementById("qcol").value;
	
	var leg = document.createElement("caption");
	var textleg = document.createTextNode(document.getElementById("legenda").value);
	
    var body = document.getElementsByTagName("body")[0];

    var tbl     = document.createElement("table");
    var tblBody = document.createElement("tbody");

	for (var j = 0; j < lin; j++) {
		var row = document.createElement("tr");

		for (var i = 0; i < col; i++) {
			var cell = document.createElement("td");
			var cellText = document.createTextNode(" ");
			cell.appendChild(cellText);
			row.appendChild(cell);
		}

		tblBody.appendChild(row);
	}

	tbl.appendChild(tblBody);
	leg.appendChild(textleg);
	tbl.appendChild(leg);
	body.appendChild(tbl);
	tbl.setAttribute("border", "1");
	tbl.setAttribute("cellpadding", "30");
	tbl.setAttribute("id",document.getElementById("id").value);
	


}

function validagem(){

	validar_id();
	validar_leg();
	validar_lin();
	validar_col();
	
	tabela();
}