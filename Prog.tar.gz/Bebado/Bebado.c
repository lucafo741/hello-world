#include <stdio.h>
#include <stdlib.h>
#include <time.h>



void main(){

    srand ( time(NULL) );

    int a;
    long int contador, max=0, min=0;
    unsigned long int passos, i;

    while(1){
        printf("Entre com o numero de passos a serem feitos: ");
        scanf("%ld",&passos);
        contador=0;
        max=min=0;
        for(i=0;i<passos;i++){
            a=rand()%2;
            if(a==0)
                contador--;
            if(a==1)
                contador++;
            if(max<contador)
                max=contador;
            if(min>contador)
                min=contador;
        }
        printf("O contador parou em: %ld\nMaximo atingido: %ld\nMinimo atingido: %ld\n\n", contador,max,min);
    }
}
