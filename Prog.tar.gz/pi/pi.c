#include <stdio.h>
#include <stdlib.h>
#include <time.h>

void main(){

    srand(time(NULL));

    float limiteX, limiteY, pi, contadorQ, contadorC;
    unsigned long int i, passos;

    while(1){
        contadorC=0;
        contadorQ=0;
        printf("Entre com o numero de pontos a serem jogados no quadrado: ");
        scanf("%ld", &passos);
        for(i=0;i<passos;i++){
            limiteX=(float)(rand()%RAND_MAX+1)/RAND_MAX*10;
            limiteY=(float)(rand()%RAND_MAX+1)/RAND_MAX*10;
            if((limiteX*limiteX+limiteY*limiteY)<100)
                contadorC++;
            contadorQ++;
        }
        printf("%f",contadorQ/contadorC);
        pi=(float)4/(contadorQ/contadorC);
        printf("\naproximacao de pi com %ld passos: %f",passos,pi);
        printf("\n\n");
    }
}
