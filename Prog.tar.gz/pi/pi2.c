#include <stdio.h>

void main(){

    unsigned long int i, max;
    double S;

    while(1){
        scanf("%d",&max);
        for(S=4,i=3;i<=max;i+=2){
            if((i-1)%4!=0)
                S = S - (double)4/i;
            if((i-1)%4==0)
                S = S + (double)4/i;
        }
        printf("%.20f\n",S);
    }
}
