#include <stdio.h>

int main(){

    int i;
    double pi,parcial;

    while(1){
        scanf("%d",&i);
        parcial=((i*i)+((2*i)-1));
        for(i-1;i>=1;i--){
            parcial=((i*i)/parcial)+((2*i)-1);
        }
        pi=4/parcial;
        printf("%.20f\n",pi);
    }
}
