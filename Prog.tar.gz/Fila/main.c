#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "fila.h"

typedef struct{
    int codigo;
    char nome[50];
    int status_emprestimo;
    Fila fila_reserva;
}Livro;

typedef struct{
    int codigo;
    char nome[50];
    char tipo[50];
}Cliente;

    int erro;
    Fila F;
    int escolha, i;
    Livro livro[100];
    Cliente cliente[100];
    static int indicel=1, indicec=1;
    char tmpNomeCliente[50], tmpNomeLivro[50];
    int tmpCodCliente;
    int v1=0;


void main(){


    int erro;
    Fila F;
    int escolha, i;
    Livro livro[100];
    Cliente cliente[100];
    static int indicel=1, indicec=1;
    char tmpNomeCliente[50], tmpNomeLivro[50];
    int tmpCodCliente;
    int v1=0;



    while(1){

        menu(0);
        printf("    ");scanf("%d",&escolha);
        switch (escolha) {
            case 1:
                cliente[indicec].codigo = indicec;
                printf("\nEntre com o nome do cliente: ");
                fflush(stdin);fgets(cliente[indicec].nome,50,stdin);
                printf("\nEntre com o tipo do cliente: ");
                fflush(stdin);fgets(cliente[indicec].tipo,50,stdin);
                indicec++;
                break;

            case 2:
                livro[indicel].codigo = indicel;
                printf("\nEntre com o nome do livro: ");
                scanf("%s",livro[indicel].nome);
                livro[indicel].status_emprestimo = 0;
                Create(&livro[indicel].fila_reserva);
                indicel++;
                break;

            case 3:
                printf("\n");
                for(i=1;i<indicel;i++){
                    printf("\nCodigo do livro: %d",livro[i].codigo);
                    printf("\nNome do livro: %s",livro[i].nome);
                    printf("\nStatus de emprestimo: %d",livro[i].status_emprestimo);
                    printf("\nFila de reserva: %d\n\n",livro[indicel].fila_reserva.itens[indicel]);
                }
                system("pause");
                break;

            case 4:
                printf("Entre com o nome do cliente: ");
                fflush(stdin);fgets(tmpNomeCliente,50,stdin);
                for(i=0;i<=indicec;i++){
                    if(strcmp(tmpNomeCliente,cliente[i].nome)==0){
                        tmpCodCliente = cliente[i].codigo;
                        v1=1;
                    }
                }
                if(v1!=1){
                    printf("\nCliente nao registrado.\n");
                    system("pause");
                    break;
                }
                printf("Entre com o livro a ser emprestado: ");
                fflush(stdin);fgets(tmpNomeLivro,50,stdin);
                for(i=0;i<=indicel;i++){
                    if(strcmp(tmpNomeLivro,livro[i].nome)==0)
                            livro[i].status_emprestimo = tmpCodCliente;
                else if(livro[i].fila_reserva.itens[livro[i].fila_reserva.inicio]==tmpCodCliente){
                            Sai(&livro[i].fila_reserva,livro[i].status_emprestimo,erro);

                    }
                }
                break;

            case 7:
                return;
        }
    system("cls");
    }
}
