#define TamFila 5

typedef int elem;

typedef struct {
			int inicio, fim, total;
			elem itens[TamFila];
} Fila;

void Create(Fila *F);
void Empty(Fila *F);
int IsEmpty(Fila *F);
int IsFull(Fila *F);
void Entra(Fila *F, elem *X, int *erro);
void Sai(Fila *F, elem *X, int *erro);
void Imprime(Fila *F);

