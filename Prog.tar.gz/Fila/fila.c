#include <stdio.h>
#include <stdlib.h>
#include "fila.h"


void Create(Fila *F) {
     F->inicio=0;
     F->fim=0;
     F->total=0;
     return;
}

void Empty(Fila *F) {
     F->inicio=0;
     F->fim=0;
     F->total=0;

}

int IsEmpty(Fila *F) {
    if (F->total==0)
       return 1;
    else return 0;
}

int IsFull(Fila *F) {
    if (F->total==TamFila)
       return 1;
    else return 0;
}

void Entra(Fila *F, elem *X, int *erro) {
     if (!IsFull(F)) {
          *erro=0;
          F->total++;
          F->itens[F->fim]=*X;
          if (F->fim==TamFila-1)
                F->fim=0;
          else F->fim++;
     }
     else *erro=1;
}

void Sai(Fila *F, elem *X, int *erro) {
     if (!IsEmpty(F)) {
          *erro=0;
          F->total--;
          *X=F->itens[F->inicio];
          if(F->inicio==TamFila-1)
                F->inicio=0;
          else F->inicio++;
     }
     else *erro=1;
     return;
}

void Imprime(Fila *F){
  int i;
  for (i=F->inicio;i<F->fim;i++) printf("%d ",F->itens[i]);
}

void menu(){
    printf("Escolha uma das opcoes abaixo:\n\n");
    printf("    1) Inserir usuario (IU);\n");
    printf("    2) Inserir livro (IL);\n");
    printf("    3) Consultar livros (CL);\n");
    printf("    4) Emprestar livro (EL);\n");
    printf("    5) Reservar livro (RL);\n");
    printf("    6) Devolver livro (DL);\n");
    printf("    7) Sair;\n\n");
}



