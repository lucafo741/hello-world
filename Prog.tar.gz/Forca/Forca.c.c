#include <stdio.h>
#include <string.h>
#include <stdlib.h>

void corpo(int cnt){

    if (cnt==0){
        printf("                Chances: %d\n",6-cnt);
        printf("\n");
        printf("\n");

        return;
    }
    if (cnt==1){
        printf("         O      Chances: %d\n",6-cnt);
        printf("\n");
        printf("\n");
        return;
    }
    if (cnt==2){
        printf("         O      Chances: %d\n",6-cnt);
        printf("         |  \n");
        printf("\n");
        return;
    }
    if (cnt==3){
        printf("         O      Chances: %d\n",6-cnt);
        printf("        /|  \n");
        printf("\n");
        return;
    }
    if (cnt==4){
        printf("         O      Chances: %d\n",6-cnt);
        printf("        /|\\ \n");
        printf("\n");
        return;
    }
    if (cnt==5){
        printf("         O      Chances: %d\n",6-cnt);
        printf("        /|\\ \n");
        printf("        /  \n");
        return;
    }
    if (cnt==6){
        printf("         O   \n");
        printf("        /|\\ \n");
        printf("        / \\ \n");
        printf("    Game Over !!!");
        return;
    }
}

int checagem(char palavra[100], char *palavraAux, char letra){

    int i, j;

    for(j=0,i=0;i<100 && palavra[i]!='\0' ;i++){
        if(toupper(palavraAux[i])==toupper(letra)){
            return 2;
        }
    }
    for(j=0,i=0;i<100;i++){

        if(toupper(palavra[i])==toupper(letra)){
            palavraAux[i]=toupper(letra);
            if(j==0){
                j=1;
            }
        }
    }
    return j;
}

int vitoria(char palavraAux[100]){

    int i;
    for(i=0;i<100;i++){
        if(palavraAux[i]=='_')
            return 0;
    }
    return 1;
}


void printpalavra(char palavraAux[100]){

    int i;
    for(i=0;i<100 && palavraAux[i]!='\0' ;i++){
        printf("%c ",palavraAux[i]);
    }
}

int main(){

    int win=0, i, cnt=0, resultado;

    char palavra[100]="pentelho";
    char palavraAux[100];
    char letra;
    strcpy(palavraAux,palavra);

    for(i=0;i<100 && palavraAux[i]!='\0' ;i++){
        if(palavraAux[i]!=' '){
            palavraAux[i]='_';
        }
        else
            palavraAux[i]=' ';
    }


    printf("\n\n");

    do{

        printf("\n");
        corpo(cnt);
        printf("\n");
        printf("\t\t");printpalavra(palavraAux);
        printf("\n");
        win=vitoria(palavraAux);
        printf("\n");
        printf("\nEscolha uma letra: ");
        letra = getchar();
        fflush(stdin);
        resultado = checagem(palavra,palavraAux,letra);
        system("cls");
        if(resultado==0){
            printf("A palavra nao tem esta letra...\n");
            cnt++;
        }
        if(resultado==1){
            printf("Acertou uma letra!\n");
        }
        if(resultado==2){
            printf("Voce ja escolheu esta letra anteriormente\n");
        }
        /*printf("\n");
        corpo(cnt);
        printf("\n");
        printpalavra(palavraAux);
        printf("\n");*/
        win=vitoria(palavraAux);
    printf("\n");
    }while(cnt<6 && win==0);


    if(win==1){
        printf("\n\n\n\n\n\t\t",6-cnt);
        printpalavra(palavraAux);
        printf("\n\n\tParabens! Voce venceu!\n\n");
    }
    if(cnt==6){
        printf("\n\t\tVoce perdeu :\(\n\n");
    }

    system("pause");
}
