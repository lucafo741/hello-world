#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <math.h>

/*
    -1 = pe�a fechada
    0...8 = numero de bombas(9) adjacentes
    9 = pe�a fechada com bomba
*/

void printTab(int **TAB, int l, int c){     //imprime o tabuleiro
    int i, j;
    printf("   ");
    for(j=0;j<c;j++)
        printf(" %d  ",j);
    printf("\n");
    for(i=0;i<l;i++){

        printf("  +");
        for(j=0;j<c;j++)
            printf("---+");
        printf("\n%d |",i);
        for(j=0;j<c;j++){
            if(TAB[i][j]==-1 || TAB[i][j]==9)
                printf(" * |");
            else if(TAB[i][j]==0 || TAB[i][j]==-2)
                printf("   |");
            else if(TAB[i][j]==900 || TAB[i][j]==-100)
                printf(" m |");
            else if(TAB[i][j]==1800 || TAB[i][j]==-200)
                printf(" ? |");
            else printf(" %d |",TAB[i][j]);
        }

        printf(" %d\n",i);
    }
    printf("  +");
    for(j=0;j<c;j++)
        printf("---+");
    printf("\n   ");
    for(j=0;j<c;j++)
        printf(" %d  ",j);
    printf("\n");
}

int win(int **TAB, int l, int c){           //checa se o jogador ganhou: 0 se n, 1 se s

    int i, j;
    for(i=0;i<l;i++)
        for(j=0;j<c;j++)
            if(TAB[i][j]==-1 || TAB[i][j]==-100 || TAB[i][j]==-200)
                return(0);
    return 1;
}

int checkaround(int **TAB, int l, int c, int jl, int jc, int *Flag){
    int counter=0;
    if(jc!=0){      // esq
        if(TAB[jl][jc-1]==9 || TAB[jl][jc-1]==900 || TAB[jl][jc-1]==1800)
            counter++;
        else if(abs(TAB[jl][jc-1])>99){
            *Flag=1;
        }
        if(jl!=0){   // esq sup
            if(TAB[jl-1][jc-1]==9 || TAB[jl-1][jc-1]==900 || TAB[jl-1][jc-1]==1800)
                counter++;
            else if(abs(TAB[jl-1][jc-1])>99)
                *Flag=1;
        }
    }
    if(jc!=c){      // dir
        if(TAB[jl][jc+1]==9 || TAB[jl][jc+1]==900 || TAB[jl][jc+1]==1800)
            counter++;
        else if(abs(TAB[jl][jc+1])>99)
            *Flag=1;
        if(jl!=l){   // dir inf
            if(TAB[jl+1][jc+1]==9 || TAB[jl+1][jc+1]==900 || TAB[jl+1][jc+1]==1800)
                counter++;
            else if(abs(TAB[jl+1][jc+1])>99)
                *Flag=1;
        }
    }
    if(jl!=0){      // sup
        if(TAB[jl-1][jc]==9 || TAB[jl-1][jc]==900 || TAB[jl-1][jc]==1800)
            counter++;
        else if(abs(TAB[jl-1][jc])>99)
            *Flag=1;
        if(jc!=c){   // sup dir
            if(TAB[jl-1][jc+1]==9 || TAB[jl-1][jc+1]==900 || TAB[jl-1][jc+1]==1800)
                counter++;
            else if(abs(TAB[jl-1][jc+1])>99)
                *Flag=1;
        }
    }
    if(jl!=l){      // inf
        if(TAB[jl+1][jc]==9 || TAB[jl+1][jc]==900 || TAB[jl+1][jc]==1800)
            counter++;
        else if(abs(TAB[jl+1][jc])>99)
            *Flag=1;
        if(jc!=0){   // inf esq
            if(TAB[jl+1][jc-1]==9 || TAB[jl+1][jc-1]==900 || TAB[jl+1][jc-1]==1800)
                counter++;
            else if(abs(TAB[jl+1][jc-1])>99)
                *Flag=1;
        }
    }

    return(counter);

}

/*
int jogada: faz a jogada
retorna:
    9 se a jogada deu numa mina;


*/

int jogada(int **TAB, int l, int c, int jl, int jc){

    int flag=0;
    if(TAB[jl][jc]==9)
        return(9);
    if(TAB[jl][jc]==-2)
        return;
    int num;
    num=checkaround(TAB,l,c,jl,jc,&flag);
    TAB[jl][jc]=num;
    if(num==0)
        TAB[jl][jc]=-2;
    if(num==0 && flag==0){
        if(jc!=0){      // esq
            jogada(TAB,l,c,jl,jc-1);
            if(jl!=0)   // esq sup
                jogada(TAB,l,c,jl-1,jc-1);
        }
        if(jc!=c){      // dir
            jogada(TAB,l,c,jl,jc+1);
            if(jl!=l)   // dir inf
                jogada(TAB,l,c,jl+1,jc+1);
        }
        if(jl!=0){      // sup
            jogada(TAB,l,c,jl-1,jc);
            if(jc!=c)   // sup dir
                jogada(TAB,l,c,jl-1,jc+1);
        }
        if(jl!=l){      // inf
            jogada(TAB,l,c,jl+1,jc);
            if(jc!=0)   // inf esq
                jogada(TAB,l,c,jl+1,jc-1);
        }
    }
    return(num);
}


int main(){


    int L, C, q, **tab;
    int i, j, I, J, result;
    char c;

    do{
        printf("linhas e colunas: ");
        scanf("%d%d",&L,&C);       //le as paradas: linhas, colunas e minas;
        system("cls");
    }while(L<1 || C<1);
    do{
        printf("minas: ");
        scanf("%d",&q);
        system("cls");
    }while(q>L*C);

    tab = malloc(L*sizeof(int*));       //cria o tabuleiro
    for (i=0;i<L;i++){
        tab[i] = malloc(C*sizeof(int));
    }
    for (i=0;i<L;i++)
        for(j=0;j<C;j++)
            tab[i][j]=-1;

    srand(time(NULL));

    for(i=0;i<q;i++){       //coloca as minas
        I=rand()%L;
        J=rand()%C;
        if(tab[I][J]==-1)
            tab[I][J]=9;
        else i--;
    }
    do{
        do{
            printTab(tab,L,C);              //imprime tabuleiro
            printf("Digite sua jogada:\n"); //pede a jogada
            scanf("%d",&I);            //le a jogada
            scanf("%d",&J);
            scanf("%c",&c);
            system("cls");                  //limpa a tela (windows)
        }while((tab[I][J]!=-1 && tab[I][J]!=9) || I<0 || J<0 || I>=L || J>=C || (c!='v' && c!='m' && c!='d'));
        if(c=='v')
            result=jogada(tab,L-1,C-1,I,J); //faz a jogada. Guarda retorno em result
        else if (c=='m')
            tab[I][J]*=100;
        else if (c=='d')
            tab[I][J]*=200;
    }while(win(tab,L,C)==0 && result!=9);
    if(result==9){
        printf("You Looooose!\n");
    }
    else printf("You WIN!\n");
    printTab(tab,L,C);
    /*for (i=0;i<L;i++){
        for(j=0;j<C;j++)
            printf("%d ",tab[i][j]);
        printf("\n");
    }*/
    return (0);
}
