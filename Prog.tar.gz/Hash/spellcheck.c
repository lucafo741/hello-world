/*
 * COMP3231 Optional C Assignment Exercise 1
 *
 * Spell checker using hash table
 */

#include <string.h>
#include <stdlib.h>
#include <stdio.h>

#define	HASHTABLE_SIZE	1000000
#define	MAXWORD		1024

struct hashchain {
	struct hashchain *next;
	char             *string;
};

typedef struct hashchain hashChain;

/* global hash table (automatically initialized to NULL) */
struct hashchain *hashtable[HASHTABLE_SIZE];


/*
 * hashpjw() -- hash function from P. J. Weinberger's C compiler
 *              call with NUL-terminated string s.
 *              returns value in range 0 .. HASHTABLE_SIZE-1
 *
 * Reference: Alfred V. Aho, Ravi Sethi, Jeffrey D. Ullman
 *            _Compilers: Principles, Techniques, and Tools_
 *            Addison-Wesley, 1986.
 */


hashpjw(const char *s){
	const char *p;
	unsigned int h, g;

	h = 0;

	for (p = s; *p != '\0'; p++) {
		h = (h << 4) + *p;
		g = h & 0xf0000000;
		if (g != 0) {
			h ^= g >> 24;
			h ^= g;
		}
	}
	return h % HASHTABLE_SIZE;
}

int
main(void)
{
	FILE *wordfile;
	char buf[MAXWORD];
    int iter;
	wordfile = fopen("./words", "r");

    for(iter=0; iter<HASHTABLE_SIZE; iter++){
        hashtable[iter]=malloc(sizeof(hashChain));
    }

	while (fscanf(wordfile,"%s",buf) != EOF) {
		hashtable[hashpjw(buf)]->string=buf;
	}

	printf("Spell checker ready.  Type a word now.\n");

	while (fgets(buf, sizeof buf, stdin) != NULL) {
		/* look up word in hash table */
        if(buf==hashtable[hashpjw(buf)]->string)
            printf("yes\n");
        else
            printf("no\n");
		/* print yes or no */


	/* free all hash chains */

	return 0;
}
