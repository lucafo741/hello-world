#include <stdio.h>
#include <math.h>

void raizes(int a,int b, int c, float *x1, float *x2){

    int delta=( (b*b) - 4*a*c);

    *x1=(-b + sqrt(delta))/2*a;
    *x2=(-b - sqrt(delta))/2*a;
}

int main(){

    int a,b,c;
    float x1,x2;
    printf("Entre com os coeficientes (inteiros) da equacao:\n");
    printf("a: "); scanf("%d",&a);
    printf("\nb: "); scanf("%d",&b);
    printf("\nc: "); scanf("%d",&c);

    printf("Sua equacao e: (%d)x^2 + (%d)x + (%d)",a,b,c);
    raizes(a,b,c,&x1,&x2);

    printf("\n\nAs raizes da sua equacao sao:\nx1=%.2f\nx2=%.2f\n",x1,x2);

    system("pause");
}
