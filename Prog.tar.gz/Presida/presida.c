#include <stdio.h>
#include <stdlib.h>
#include <time.h>

void bubble( int v[], int qtd ){ //fun�ao para ordenar as cartas
  int i;
  int j;
  int aux;
  int k = qtd - 1 ;

  for(i = 0; i < qtd; i++)
  {
     for(j = 0; j < k; j++)
     {
        if(v[j] > v[j+1])
        {
            aux = v[j];
        v[j] = v[j+1];
        v[j+1]=aux;
        }
     }
     k--;
  }
}

void DarAsCartas(int *p1, int *p2, int *p3, int *p4, int deck[4][13], int p){ //fun�ao para distribuir as cartas

    int iR, jR, I;
    srand (time(NULL)+p);
    for(I=0;I<13;I++){
        do{
            iR=rand()%4;
            jR=rand()%13;
        }while(deck[iR][jR]==0);
        p1[I]=deck[iR][jR];
        deck[iR][jR]=0;
    }
    for(I=0;I<13;I++){
        do{
            iR=rand()%4;
            jR=rand()%13;
        }while(deck[iR][jR]==0);
        p2[I]=deck[iR][jR];
        deck[iR][jR]=0;
    }
    for(I=0;I<13;I++){
        do{
            iR=rand()%4;
            jR=rand()%13;
        }while(deck[iR][jR]==0);
        p3[I]=deck[iR][jR];
        deck[iR][jR]=0;
    }
    for(I=0;I<13;I++){
        do{
            iR=rand()%4;
            jR=rand()%13;
        }while(deck[iR][jR]==0);
        p4[I]=deck[iR][jR];
        deck[iR][jR]=0;
    }
}

int cH(int v[13]){   //retorna 0 se a mao est� vazia e 1 se n�o
    int i, sum=0;
    for(i=0;i<13;i++){
        sum+=v[i];
    }
    if(sum>0)
        return(1);
    return(0);
}

int move1(int *p, int *table){   //jogador um faz sua jogada. 0 se o jogador nao tinha o que jogar. 1 se jogou.
    int i;
    if(table[0]==0){        //mesa vazia?
        for(i=0;i<13;i++){  //corre pelos slots de carta na mao do cara
            if(p[i]!=0){        //slot nao vazio?
                if(i==12){          //ultimo slot? entao essa � a carta a ser jogada
                    table[0]=1;
                    table[1]=p[i];
                    p[i]=0;
                    return(1);
                }
                if(p[i+1]==p[i]){       //estou numa dupla?
                    if(i!=11){                  //penultimo slot?
                        if(p[i+2]==p[i]){           //estou num trio?
                            if(i!=10){                  //antipenultimo slot?
                                if(p[i+3]==p[i]){       //quarteto?
                                    table[0]=4;         //coloca o quarteto
                                    table[1]=p[i];
                                    p[i]=0;
                                    p[i+1]=0;
                                    p[i+2]=0;
                                    p[i+3]=0;
                                    return(1);
                                }
                                else{                   //se nao eh quarteto eh trio. coloca o trio
                                    table[0]=3;
                                    table[1]=p[i];
                                    p[i]=0;
                                    p[i+1]=0;
                                    p[i+2]=0;
                                    return(1);
                                }
                            }
                            else{                   //se � trio e estou no antipenultimo slot coloca o trio
                                    table[0]=3;
                                    table[1]=p[i];
                                    p[i]=0;
                                    p[i+1]=0;
                                    p[i+2]=0;
                                    return(1);
                                }
                        }
                        else{               //se nao estou num trio estou numa dupla. coloca a dupla
                            table[0]=2;
                            table[1]=p[i];
                            p[i]=0;
                            p[i+1]=0;
                            return(1);
                        }
                    }
                    else{               //se � dupla e estou no penultimo slot coloca a dupla
                            table[0]=2;
                            table[1]=p[i];
                            p[i]=0;
                            p[i+1]=0;
                            return(1);
                        }
                }
                else{               //se nao eh dupla coloca a carta desse slot
                    table[0]=1;
                    table[1]=p[i];
                    p[i]=0;
                    return(1);
                }
            }
            else continue;
        }
    }
    else if(table[0]==1){
        for(i=0;i<13;i++){
            if(p[i]!=0){
                if(i==12){
                    if(p[i]>table[1]){
                        table[1]=p[i];
                        p[i]=0;
                        return(1);
                    }
                    else{
                        return(0);
                    }
                }
                else{
                    if(p[i+1]!=p[i]){           //estou numa dupla?
                        if(p[i]>table[1]){
                            table[1]=p[i];
                            p[i]=0;
                            return(1);
                        }
                    }
                    else{           //para nao checar os slots seguintes se eu estiver numa dupla,
                        i++;
                        if(i!=12){
                            if(p[i+1]==p[i]){   //trio ou
                                i++;
                                if(i!=12){
                                    if(p[i+1]==p[i]){   //quarteto
                                        i++;
                                        if(i==12){
                                            return(0);
                                        }
                                        else{
                                            continue;
                                        }
                                    }
                                    else{
                                        continue;
                                    }
                                }
                                else{
                                    return (0);
                                }
                            }
                            else{
                                continue;
                            }
                        }
                        else{
                            return(0);
                        }

                    }
                }
            }
        }
    }
    else if(table[0]==2){
        for(i=0;i<13;i++){
            if(p[i]!=0){
                if(i==12){
                    return(0);
                }
                if(i==11){
                    if(p[i]==p[i+1]){
                        if(p[i]>table[1]){
                            table[1]=p[i];
                            p[i]=0;
                            p[i+1]=0;
                            return(1);
                        }
                        else return(0);
                    }
                    else return(0);
                }
                if(p[i]==p[i+1]){
                    if(p[i+2]!=p[i]){
                        if(p[i]>table[1]){
                            table[1]=p[i];
                            p[i]=0;
                            p[i+1]=0;
                            return(1);
                        }
                    }
                    else if(i==10){
                        return (0);
                    }
                    else if(p[i+3]==p[i]){
                        if(i==9){
                            return(0);
                        }
                        else{
                            i+=3;
                            continue;
                        }
                    }
                    else{
                        i+=2;
                        continue;
                    }
                }
                else continue;
            }
        }
    }
    else if(table[0]==3){
        for(i=0;i<13;i++){
            if(p[i]!=0){
                if(i==12 || i==11){
                    return(0);
                }
                if(i==10){
                    if(p[i+2]==p[i] && p[i]>table[1]){
                            table[1]=p[i];
                            p[i]=0;
                            p[i+1]=0;
                            p[i+2]=0;
                            return(1);
                    }
                    else return(0);
                }
                else{
                    if(p[i+3]==p[i]){       //� um quarteto?
                        if(i==9){
                            return(0);
                        }
                        else{
                            i+=3;
                            continue;
                        }
                    }
                    if(p[i+2]!=p[i]){
                        if(p[i]==p[i+1]){
                            i++;
                            continue;
                        }
                        else continue;
                    }
                    else{
                        if(p[i]>table[1]){
                            table[1]=p[i];
                            p[i]=0;
                            p[i+1]=0;
                            p[i+2]=0;
                            return(1);
                        }
                    }
                }
            }
        }
    }
    else if(table[0]==4){
        for(i=0;i<13;i++){
            if(p[i]!=0){
                if(i==12 || i==11 || i==10){
                    return(0);
                }
                if(i==9){
                    if(p[i+3]==p[i] && p[i]>table[1]){
                            table[1]=p[i];
                            p[i]=0;
                            p[i+1]=0;
                            p[i+2]=0;
                            p[i+3]=0;
                            return(1);
                    }
                    else return(0);
                }
                else{
                    if(p[i+3]==p[i]){
                        if(p[i]>table[1]){
                            table[1]=p[i];
                            p[i]=0;
                            p[i+1]=0;
                            p[i+2]=0;
                            p[i+3]=0;
                            return(1);
                        }
                        else{
                            i+=3;
                            continue;
                        }
                    }
                    else if(p[i+2]==p[i]){
                        i+=2;
                        continue;
                    }
                    else if(p[i+1]==p[i]){
                        i++;
                        continue;
                    }
                    else continue;
                }
            }
        }
    }
}


int main(){

    int i, j, m1, m2, m3, m4, M=1, I=0, S[4]={0,0,0,0}, C;
    int score[4][4];
    int baralho[4][13];
    int mesa[2]={0,0};


    int player1[13];
    int player2[13];
    int player3[13];
    int player4[13];

    for(i=0;i<4;i++)
        for(j=0;j<4;j++)
            score[i][j]=0;

    while(I<1000000){

        for(i=0;i<4;i++){       //cria o baralho (matriz)
            for(j=0;j<13;j++){
                baralho[i][j]=j+1;
            }
        }
        for(i=0;i<4;i++)
            S[i]=0;
        DarAsCartas(player1, player2, player3, player4, baralho, I); //distribui as cartas

        bubble(player1,13); //jogadores ordenam as cartas
        bubble(player2,13);
        bubble(player3,13);
        bubble(player4,13);
        mesa[0]=0;
        mesa[1]=0;
        /*for(i=0;i<13;i++){
            printf("%d ",player1[i]);
        }
        printf("\n");

        for(i=0;i<13;i++){
            printf("%d ",player2[i]);
        }
        printf("\n");

        for(i=0;i<13;i++){
            printf("%d ",player3[i]);
        }
        printf("\n");

        for(i=0;i<13;i++){
            printf("%d ",player4[i]);
        }
        printf("\n\n\n\n");*/
        M=1;
        C=0;
        while( (cH(player1) + cH(player2) + cH(player3) + cH(player4))>1){
            //printf("\t\t\t%d\n",M);
            if(M==1){
                m1=move1(player1,mesa);
                //printf("%d %d\n",mesa[0], mesa[1]);
                m2=move1(player2,mesa);
                //printf("%d %d\n",mesa[0], mesa[1]);
                m3=move1(player3,mesa);
                //printf("%d %d\n",mesa[0], mesa[1]);
                m4=move1(player4,mesa);
                //printf("%d %d\n",mesa[0], mesa[1]);
                mesa[0]=0;
                mesa[1]=0;
                if(m4==1)
                    M=4;
                else if(m3==1)
                    M=3;
                else if(m2==1)
                    M=2;
            }
            else if(M==2){
                m2=move1(player2,mesa);
                //printf("%d %d\n",mesa[0], mesa[1]);
                m3=move1(player3,mesa);
                //printf("%d %d\n",mesa[0], mesa[1]);
                m4=move1(player4,mesa);
                //printf("%d %d\n",mesa[0], mesa[1]);
                m1=move1(player1,mesa);
                //printf("%d %d\n",mesa[0], mesa[1]);
                mesa[0]=0;
                mesa[1]=0;
                if(m1==1)
                    M=1;
                else if(m4==1)
                    M=4;
                else if(m3==1)
                    M=3;
            }
            else if(M==3){
                m3=move1(player3,mesa);
                //printf("%d %d\n",mesa[0], mesa[1]);
                m4=move1(player4,mesa);
                //printf("%d %d\n",mesa[0], mesa[1]);
                m1=move1(player1,mesa);
                //printf("%d %d\n",mesa[0], mesa[1]);
                m2=move1(player2,mesa);
                //printf("%d %d\n",mesa[0], mesa[1]);
                mesa[0]=0;
                mesa[1]=0;

                if(m2==1)
                    M=2;
                else if(m1==1)
                    M=1;
                else if(m4==1)
                    M=4;
            }
            else if(M==4){
                m4=move1(player4,mesa);
                //printf("%d %d\n",mesa[0], mesa[1]);
                m1=move1(player1,mesa);
                //printf("%d %d\n",mesa[0], mesa[1]);
                m2=move1(player2,mesa);
                //printf("%d %d\n",mesa[0], mesa[1]);
                m3=move1(player3,mesa);
                //printf("%d %d\n",mesa[0], mesa[1]);
                mesa[0]=0;
                mesa[1]=0;
                if(m3==1)
                    M=3;
                else if(m2==1)
                    M=2;
                else if(m1==1)
                    M=1;
            }
            /*printf("%d %d %d %d\n\n", m1, m2, m3, m4);
            for(i=0;i<13;i++){
                printf("%d ",player1[i]);
            }
            printf("\n");
            for(i=0;i<13;i++){
                printf("%d ",player2[i]);
            }
            printf("\n");
            for(i=0;i<13;i++){
                printf("%d ",player3[i]);
            }
            printf("\n");
            for(i=0;i<13;i++){
                printf("%d ",player4[i]);
            }
            printf("\n\n\n\n");*/

            if(cH(player1)==0 && S[0]==0){
                score[0][C]++;
                C++;
                S[0]=1;
            }
            if(cH(player2)==0 && S[1]==0){
                score[1][C]++;
                C++;
                S[1]=1;
            }
            if(cH(player3)==0 && S[2]==0){
                score[2][C]++;
                C++;
                S[2]=1;
            }
            if(cH(player4)==0 && S[3]==0){
                score[3][C]++;
                C++;
                S[3]=1;
            }
            if(C==3){

                if(cH(player1)==1)
                    score[0][3]++;
                if(cH(player2)==1)
                    score[1][3]++;
                if(cH(player3)==1)
                    score[2][3]++;
                if(cH(player4)==1)
                    score[3][3]++;
            }
        }
        I++;
        //system("pause");
    }
    printf("\n\n");
    for(i=0;i<4;i++){
        for(j=0;j<4;j++)
            printf("%d ",score[i][j]);
        printf("\n");
    }
}
