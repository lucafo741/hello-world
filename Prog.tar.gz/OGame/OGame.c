#include <stdio.h>
#include <string.h>
#include <stdlib.h>

typedef struct ship{
    char nome[20];
    unsigned int metal;
    unsigned int cristal;
    unsigned int deuterio;
    unsigned int integridade;
    unsigned int escudo;
    unsigned int armas;
    unsigned int velocidade;
    unsigned int capacidade;
    unsigned int consumo;
}Naves;

int main(){

    int i;
    FILE *fp;
    fp = fopen("naves","r");
    Naves lista[8];

    for(i=0;i<8;i++){
        fscanf(fp,"%s %d %d %d %d %d %d %d %d %d",lista[i].nome, &lista[i].metal, &lista[i].cristal,
               &lista[i].deuterio, &lista[i].integridade, &lista[i].escudo, &lista[i].armas,
               &lista[i].velocidade, &lista[i].capacidade, &lista[i].consumo);
    }





    fclose(fp);
}
