#include <stdio.h>
#include <string.h>
#include "tadlista.h"


void menu(){

    printf("     Criar uma matriz (CM);\n");
    printf("     Destruir uma matriz (DM);\n");
    printf("     Imprimir uma matriz (IM);\n");
    printf("     Atribuir um elemento a uma matriz (AE);\n");
    printf("     Atribuir uma linha a uma matriz (AL);\n");
    printf("     Atribuir uma coluna a uma matriz (AC);\n");
    printf("     Transpor uma matriz (TM);\n");
    printf("     Somar duas matrizes (SM);\n");
    printf("     Dividir uma matiz por outra (DM);\n");
    printf("     Multiplicar uma matriz por outra (MM).\n");
    printf("     Multiplicar duas matrizes (elemento por elemento) (ME).\n");
    printf("     Finalizar a execucao");
}

void main(){


    char nomedamatriz[10],ncolc[5],nlinc[5],elementoc[10];
    int ncol, nlin, i, j;
    char opcao_menu[100];
    float elemento;
    int teste;

    Lista L;
    cria(&L);
    menu();

    do{

        printf("\n\nEntre com a opcao desejada: ");
        fflush(stdin);fgets(opcao_menu,100,stdin);
        //switch(opcao_menu){

        if(opcao_menu[0]=='C' && opcao_menu[1]=='M'){  // CM
            for(teste=0,i=3; i<100 && teste==0 ;i++){
                if(opcao_menu[i]!=' '){
                    nomedamatriz[i-3]=opcao_menu[i];
                }
                if(opcao_menu[i]==' '){
                    teste=1;
                }
            }
            for(teste=0,j=0,i;i<100 && teste==0;j++,i++){
                if(opcao_menu[i]!=' '){
                    nlinc[j]=opcao_menu[i];
                }
                if(opcao_menu[i]==' '){
                    teste=1;
                }
            }
            nlin = atoi(nlinc);

            for(teste=0,i,j=0;i<100 && teste==0;i++,j++){
                if(opcao_menu[i]!=' '){
                    ncolc[j]=opcao_menu[i];
                }
                if(opcao_menu[i]==' '){
                    teste=1;
                }
            }
            ncol = atoi(ncolc);

            inserir(&L,nomedamatriz,nlin,ncol);
        }

        if(opcao_menu[0]=='D' && opcao_menu[1]=='M'){  // DM
            for(teste=0,i=3; i<100 && teste==0 ;i++){
                if(opcao_menu[i]!=' '){
                    nomedamatriz[i-3]=opcao_menu[i];
                }
                if(opcao_menu[i]==' '){
                    teste=1;
                }
            }

        }eliminar(&L,nomedamatriz);

        if(opcao_menu[0]=='I' && opcao_menu[1]=='M'){  // IM
            for(teste=0,i=3; i<100 && teste==0 ;i++){
                if(opcao_menu[i]!=' '){
                    nomedamatriz[i-3]=opcao_menu[i];
                }
                if(opcao_menu[i]==' '){
                    teste=1;
                }
            }
            imprimir(&L,nomedamatriz);
        }

        if(opcao_menu[0]=='A' && opcao_menu[1]=='E'){

            for(teste=0,i=3; i<100 && teste==0 ;i++){
                if(opcao_menu[i]!=' '){
                    nomedamatriz[i-3]=opcao_menu[i];
                }
                if(opcao_menu[i]==' '){
                    teste=1;
                }
            }
            for(teste=0,j=0,i;i<100 && teste==0;j++,i++){
                if(opcao_menu[i]!=' '){
                    nlinc[j]=opcao_menu[i];
                }
                if(opcao_menu[i]==' '){
                    teste=1;
                }
            }
            nlin = atoi(nlinc);

            for(teste=0,i,j=0;i<100 && teste==0;i++,j++){
                if(opcao_menu[i]!=' '){
                    ncolc[j]=opcao_menu[i];
                }
                if(opcao_menu[i]==' '){
                    teste=1;
                }
            }
            ncol = atoi(ncolc);

            for(teste=0,i,j=0;i<100 && teste==0;i++,j++){
                if(opcao_menu[i]!=' '){
                    elementoc[j]=opcao_menu[i];
                }
                if(opcao_menu[i]==' '){
                    teste=1;
                }
            }
            elemento = atof(elementoc);
            if(atribuir_elem(&L,nomedamatriz,nlin,ncol,elemento)==0){
                printf("\n\tAs coordenadas nao se encontram na matriz\n");
            }
            if(atribuir_elem(&L,nomedamatriz,nlin,ncol,elemento)==1){
                printf("\n\tElemento adicionado com sucesso");
            }
        }

    }while(opcao_menu[0]!='F');

    finaliza(&L);

}
