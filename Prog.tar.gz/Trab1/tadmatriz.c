#include "tadlista.h"
#include <string.h>
#include <stdio.h>


int atribuir_elem(Lista *L, char nomedamatriz[15], int lin, int col, float x){

    no *p;
    int teste=0;
    p=L->inicio;
    while ((p!=NULL) && (!teste)) {
        if((strcmp(p->info.nome,nomedamatriz))==0){
            if(lin>=p->info.nlin || col>=p->info.ncol){
                return 0;
            }
            else{
                p->info.matriz[lin][col]=x;
                return 1;
            }
            break;
        }
        else{
            p=p->prox;
        }
    }
}

//int atribuir_linha(Lista *L, char)
