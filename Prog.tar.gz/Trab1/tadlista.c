#include "tadlista.h"
#include <string.h>
#include <stdio.h>
#include <stdlib.h>

void cria(Lista *L) {
     L->inicio=NULL;
     L->fim=NULL;
}

void finaliza(Lista *L) {
     no *p;
     p=L->inicio;
     while (p!=NULL) {
           L->inicio=L->inicio->prox;
           free(p);
           p=L->inicio;
     }
     L->fim=NULL;
}

void inserir(Lista *L, char nomedametriz[15], int lin, int col) {
     int i;
     no *p;

     //p=(no*) calloc((lin*lin*col),sizeof(no));
     p=(no*) calloc((1),sizeof(no));
     p->info.matriz=(float**) calloc(lin,sizeof(float*));
     //printf("\t\tLinhas alocadas\n");
     for ( i = 0; i < lin; i++ ) {
        p->info.matriz[i] = (float*) calloc (col, sizeof(float));
     //printf("\t\tColuna alocada\n");
     }
     p->prox=NULL;
     strcpy(p->info.nome,nomedametriz);
     p->info.nlin=lin;
     p->info.ncol=col;

     if (L->inicio==NULL)
        L->inicio=p;
     else L->fim->prox=p;
     L->fim=p;

}

void eliminar(Lista *L, char nomedamatriz[15]) {
     no *p, *aux;
     int teste=0;

     p=L->inicio;
     while ((p!=NULL) && (!teste)) {
           if ((strcmp(p->info.nome,nomedamatriz))==0) {
              if (p==L->inicio)
                 L->inicio=L->inicio->prox;
              else if (p==L->fim) {
                   L->fim=aux;
                   L->fim->prox=NULL;
              }
              else aux->prox=p->prox;
              free(p);
              teste=1;
           }
           else {
                aux=p;
                p=p->prox;
           }
     }
}

int tamanho(Lista *L) {
    no *p;
    int contador=0;

    p=L->inicio;
    while (p!=NULL) {
          contador++;
          p=p->prox;
    }
    return(contador);
}

int tamanho_rec(no* p) {
    if (p==NULL)
       return(0);
    else return(1+tamanho_rec(p->prox));
}

void imprimir(Lista *L,char nomedamatriz[15]) {
    int i,j;
    no *p;
    int teste=0;

    p=L->inicio;
    while ((p!=NULL) && (!teste)) {
        if(strcmp(p->info.nome,nomedamatriz)==0){
            for(i=0;i<p->info.nlin;i++){
                for(j=0;j<p->info.ncol;j++){
                    printf("%4.2f ",p->info.matriz[i][j]);
                }
                printf("\n");
            }
            teste=1;
        }
        else{
            p=p->prox;
        }
    }
}
