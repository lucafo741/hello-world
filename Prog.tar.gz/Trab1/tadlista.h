#include <stdio.h>

typedef int elem;

typedef struct Matrix{
    char nome[15];
    int nlin, ncol;
    float **matriz;

}Matriz;

typedef struct bloco{
    struct bloco *prox;
    Matriz info;
}no;

typedef struct {
        no *inicio, *fim;
} Lista;



int atribuir_elem(Lista *L, char nomedamatriz[15], int lin, int col, float x);
void cria(Lista *L);
void finaliza(Lista *L);
void inserir(Lista *L, char nomedametriz[15], int lin, int col);
void eliminar(Lista *L, char nomedamatriz[15]);
void imprimir(Lista *L,char nomedamatriz[15]);
