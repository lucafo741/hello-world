#define TamPilha 5

typedef int elem;

typedef struct {
			int topo;
			elem itens[TamPilha];
} Pilha;

void Create(Pilha *P);
void Empty(Pilha *P);
int IsEmpty(Pilha *P);
int IsFull(Pilha *P);
void Push(Pilha *P, elem *X, int *erro);
void Pop(Pilha *P, elem *X, int *erro);
