#include "pilha.h"
#include <stdio.h>

void Create(Pilha *P) {
     P->topo=0;
}

void Empty(Pilha *P) {
     P->topo=0;
}

int IsEmpty(Pilha *P) {
    if (P->topo==0)
       return 1;
    return 0;
}

int IsFull(Pilha *P) {
    if (P->topo==TamPilha)
       return 1;
    return 0;
}

void Push(Pilha *P, elem *X, int *erro) {
     if (!IsFull(P)) {
          *erro=0;
          P->topo++;
          P->itens[P->topo]=*X;
     }
     else *erro=1;
}

void Pop(Pilha *P, elem *X, int *erro) {
     if (!IsEmpty(P)) {
          *erro=0;
          *X=P->itens[P->topo];
          P->topo--;
     }
     else *erro=1;
}

void Top(Pilha *P, elem *X, int *erro) {
     if (!IsEmpty(P)) {
          *erro=0;
          *X=P->itens[P->topo];
     }
     else *erro=1;
}

void menu(){
    printf("Escolha uma das opcoes abaixo:\n\n");
    printf("    1) Criar uma nova pilha / Esvaziar a pilha;\n");
    printf("    2) Checar se a(s) pilha(s) esta(o) vazia(s);\n");
    printf("    3) Checar se a(s) pilha(s) esta(o) cheia(s);\n");
    printf("    4) Colocar elemento na(s) pilha(s);\n");
    printf("    5) Retirar elemento na(s) pilha(s);\n");
    printf("    6) Imprimir o elemento do topo da(s) pilha(s);\n");
    printf("    7) Sair (a(s) pilha(s) e seus elementos serao apagados definitivamente.\n\n");
}
void main(){


    Pilha P, Q;
    int erro;
    int escolha, escolha2,qnt=0; //qnt = quantidade de pilhas
    elem elemento;
    Create(&P);
    while(1){

        menu();
        printf("    ");scanf("%d",&escolha);
        switch (escolha) {
            case 1:  //Criar Pilhas
                printf("    Voce deseja criar uma ou duas pilhas?\n");
                printf("    ");scanf("%d",&escolha2);
                switch (escolha2){
                    case 1:
                        Create(&P);
                        qnt=1;
                        printf("    Pilha criada com sucesso!");
                        system("pause");
                        break;
                    case 2:
                        Create(&P);
                        Create(&Q);
                        qnt=2;
                        printf("    Pilha criada com sucesso!");
                        system("pause");
                        break;
                }
                break;
            case 2:  //Checar se est� vazia
                if(qnt==0){
                    printf("    Ainda nao ha nenhuma pilha criada.\n\n");
                    break;
                }
                if(qnt==2){
                    if(IsEmpty(&P)==1)
                        printf("    A pilha 1 esta vazia\n");
                    else printf("   A pilha 1 nao esta vazia\n");

                    if(IsEmpty(&Q)==1)
                        printf("    A pilha 2 esta vazia\n");
                    else printf("   A pilha 2 nao esta vazia\n");
                    system("pause");
                break;
                }
                if(qnt==1){
                    if(IsEmpty(&P)==1)
                        printf("    A pilha esta vazia\n");
                    else printf("   A pilha nao esta vazia\n");
                    break;
                }
            case 3:  //Checar se est� cheia
                if(qnt==0){
                    printf("    Ainda nao ha nenhuma pilha criada.\n\n");
                    break;
                }
                if(qnt==2){
                    if(IsFull(&P)==1)
                        printf("    A pilha 1 esta cheia\n");
                    else printf("   A pilha 1 nao esta cheia\n");

                    if(IsFull(&Q)==1)
                        printf("    A pilha 2 esta cheia\n");
                    else printf("   A pilha 2 nao esta cheia\n");
                    system("pause");
                    break;
                }
                if(qnt==1){
                    if(IsFull(&P)==1)
                        printf("    A pilha esta cheia\n");
                    else printf("   A pilha nao esta cheia\n");
                    break;
                }
            case 4:  //Colocar elemento
                if(qnt==0){
                    printf("    Ainda nao ha nenhuma pilha criada.\n\n");
                    break;
                }
                if(qnt==2){
                    printf("    Voce deseja colocar um elemento na pilha 1, na pilha 2 ou em ambas?\n");
                    printf("    1) Pilha 1;\n    2) Pilha 2;\n    3) Ambas;\n    ");
                    scanf("%d",&escolha2);
                    switch (escolha2){

                        case 1:
                            printf("    Escolha o valor a ser inserido na pilha 1: ");
                            scanf("%d",&elemento);
                            Push(&P,&elemento,&erro);
                            if(erro==0)
                                printf("    O elemento %d foi colocado na pilha.\n\n",elemento);
                            if(erro==1)
                                printf("    A pilha 1 esta cheia.\n\n");
                            printf("    ");system("pause");
                            break;

                        case 2:
                            printf("    Escolha o valor a ser inserido na pilha 2: ");
                            scanf("%d",&elemento);
                            Push(&Q,&elemento,&erro);
                            if(erro==0)
                                printf("    O elemento %d foi colocado na pilha.\n\n",elemento);
                            if(erro==1)
                                printf("    A pilha 2 esta cheia.\n\n");
                            printf("    ");system("pause");
                        break;

                        case 3:
                            printf("    Escolha o valor a ser inserido na pilha 1: ");
                            scanf("%d",&elemento);
                            Push(&P,&elemento,&erro);
                            if(erro==0)
                                printf("    O elemento %d foi colocado na pilha.\n\n",elemento);
                            if(erro==1)
                                printf("    A pilha 1 esta cheia.\n\n");

                            printf("    Escolha o valor a ser inserido na pilha 2: ");
                            scanf("%d",&elemento);
                            Push(&Q,&elemento,&erro);
                            if(erro==0)
                                printf("    O elemento %d foi colocado na pilha.\n\n",elemento);
                            if(erro==1)
                                printf("    A pilha 2 esta cheia.\n\n");
                            printf("    ");system("pause");
                        break;
                    }
                break;
                }
                if(qnt==1){
                    printf("    Escolha o valor a ser inserido na pilha: ");
                    scanf("%d",&elemento);
                    Push(&P,&elemento,&erro);
                    if(erro==0)
                        printf("    O elemento %d foi colocado na pilha.\n\n",elemento);
                    if(erro==1)
                        printf("    A pilha esta cheia.\n\n");
                    printf("    ");system("pause");
                break;
                }
            case 5:  //Retirar elemento
                if(qnt==0){
                    printf("    Ainda nao ha nenhuma pilha criada.\n\n");
                    break;
                }
                if(qnt==2){
                    switch (escolha2){
                        case 1:
                            Pop(&P,&elemento,&erro);
                            if(erro==0)
                                printf("    Voce retirou o elemento %d da pilha 1.\n\n",elemento);
                            if(erro==1)
                                printf("    A pilha 1 ja esta vazia.\n\n");
                                printf("    ");system("pause");
                                break;

                        case 2:
                            Pop(&Q,&elemento,&erro);
                            if(erro==0)
                                printf("    Voce retirou o elemento %d da pilha 1.\n\n",elemento);
                            if(erro==1)
                                printf("    A pilha 2 ja esta vazia.\n\n");
                                printf("    ");system("pause");
                                break;

                        case 3:
                            Pop(&P,&elemento,&erro);
                            if(erro==0)
                                printf("    Voce retirou o elemento %d da pilha 1.\n\n",elemento);
                            if(erro==1)
                                printf("    A pilha 1 ja esta vazia.\n\n");
                                printf("    ");system("pause");

                            Pop(&Q,&elemento,&erro);
                            if(erro==0)
                                printf("    Voce retirou o elemento %d da pilha 1.\n\n",elemento);
                            if(erro==1)
                                printf("    A pilha 2 ja esta vazia.\n\n");
                                printf("    ");system("pause");
                            break;
                    }
                break;
                }
                if(qnt==1){
                    Pop(&P,&elemento,&erro);
                    if(erro==0)
                        printf("    Voce retirou o elemento %d da pilha.\n\n",elemento);
                    if(erro==1)
                        printf("    A pilha ja esta vazia.\n\n");
                        printf("    ");system("pause");
                break;
                }
            case 6:  //Verificar o primeiro elemento da pilha
                if(qnt==0){
                    printf("    Ainda nao ha nenhuma pilha criada.\n\n");
                    break;
                }
                if(qnt==2){
                    Top(&P,&elemento,&erro);
                    if(erro==1)
                        printf("    A pilha 1 esta vazia.\n\n");
                    if(erro==0)
                        printf("    Elemento no topo da pilha 1: %d\n\n",elemento);
                        printf("    ");system("pause");

                    Top(&Q,&elemento,&erro);
                    if(erro==1)
                        printf("    A pilha 2 esta vazia.\n\n");
                    if(erro==0)
                        printf("    Elemento no topo da pilha 2: %d\n\n",elemento);
                        printf("    ");system("pause");
                break;
                }
                if(qnt==1){
                    Top(&P,&elemento,&erro);
                    if(erro==1)
                        printf("    A pilha esta vazia.\n\n");
                    if(erro==0)
                        printf("    Elemento no topo da pilha: %d\n\n",elemento);
                        printf("    ");system("pause");
                break;
                }
            case 7:  //Sair
                return;
        }
        system("cls");
    }
}


