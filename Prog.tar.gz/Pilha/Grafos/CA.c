#include <stdio.h>
#include <stdlib.h>
#include <string.h>
typedef struct user{
    char id[100];
    char nome[100];
    int v;
}User;

int checkv(int *vetor,int tamanho, int n){
    int i;
    for(i=0;i<tamanho;i++)
        if(vetor[i]==n)
            return(1);
    return(0);
}
/*
CA = coeficiente de agrupamento
M = grafo
n = numero de vertices
v = vertice
*/

double ca(int M[6][6], int n, int v){
    int b,i,j,nv,cnt;    //nv = numero de vizinhos    //cnt = contador
    int *vizinhos;
    vizinhos = malloc(n*sizeof(int));

    for(i=0,nv=0;i<n;i++){
        if(M[v][i]==1){
            vizinhos[nv]=i;
            nv++;
        }
    }
    cnt=0;
    for(i=0;i<n;i++){
        if(checkv(vizinhos,nv,i)){
            for(j=0;j<n;j++){
                if(checkv(vizinhos,nv,j)){
                    if(M[i][j])
                        cnt++;
                }else continue;
            }
        }else continue;
    }
    free(vizinhos);
    return((double)cnt/(nv*(nv-1)));
}

int main(){
    /*int i, j,n=6;

    int matriz[6][6]={{0,1,0,0,1,1},
               {1,0,1,0,1,1},
               {0,1,0,1,1,1},
               {0,0,1,0,1,1},
               {1,1,1,1,0,1},
               {1,1,1,1,1,0}};
    for(i=0;i<n;i++){
        for(j=0;j<n;j++){
            printf("%d ",matriz[i][j]);
        }
        printf("\n");
    }
    int v=5;
    printf("%lf",ca(matriz,n,v));
    return 0;*/

    char coisa[10],c,medida[2],ID[100],NOME[100];

    scanf("%s",medida);

    do{
        c=getchar();
    }while(c!=':');

    fgets(ID,100,stdin);

    do{
        c=getchar();
    }while(c!=':');

    fgets(NOME,100,stdin);
    fgets(coisa,10,stdin);

    printf("%s %s",ID,NOME);
}
