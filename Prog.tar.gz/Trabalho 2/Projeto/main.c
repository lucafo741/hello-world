#include <stdio.h>
#include <string.h>
#include "ABB.h"

void printmenu(){

    printf("\n\n\t\tEscolha a opcao desejada:\n\n");
    printf("\t\tCadastramento:\n");
    printf("\t\t    1)Cadastrar titulo de eleitor;\n");
    printf("\t\t    2)Remover titulo de eleitor do cadastro;\n");
    printf("\t\t    3)Conferir se um titulo ja foi cadastrado;\n\n");
    printf("\t\tVotacao:\n");
    printf("\t\t    4)Votar;\n");
    printf("\t\t    5)Retirar voto;\n");
    printf("\t\t    6)Mostrar resultado parcial da eleicao;\n");
    printf("\t\t    7)Mostrar maior titulo que ja votou;\n");
    printf("\t\t    8)Mostrar menor titulo que ja votou;\n");
    printf("\t\t    9)Listar titulos cadastrados;\n");
    printf("\t\t   10)Listar titulos que ja votaram;\n\n");
    printf("\t\t    0)Encerrar o programa;\n\n");
}

int main(void) {
    ABB1 A;
    ABB2 B;
    nol *ini, *p, *aux;
    ini = NULL;
    int opcao, k, res, res2;
    char nome[20];
    criar(&A,&B);

    printmenu();
    printf("Sua opcao: ");
    scanf("%d",&opcao);
    while (opcao!=0) {
        if (opcao==1) {
            printf("\nDigite a o titulo a ser cadastrado: ");
            scanf("%d",&k);
            res=inserir1(&A.raiz,k);
            if (!res)
                printf("\n\nERRO\n");
        }
        else if (opcao==2) {
            printf("\nDigite titulo a ser removido do cadastro: ");
            scanf("%d",&k);
            res=remover1(&A.raiz,k);
            if (!res)
                printf("\n\nERRO\n");
        }
        else if (opcao==3) {
            printf("\nDigite titulo para buscar: ");
            scanf("%d",&k);
            res=buscar1(&A.raiz,k);
            if (res==0)
                printf("\n\nTitulo nao cadastrado\n");
            if (res==1)
                printf("\n\nTitulo cadastrado\n");
        }
        else if (opcao==4) {
            printf("\nEntre com o titulo do eleitor: ");
            scanf("%d",&k);
            res=buscar1(&A.raiz,k);
            if (res==0)
                printf("\n\nTitulo nao cadastrado\n");
            if (res==1){
                printf("Entre com o candidato escolhido pelo eleitor: ");
                fflush(stdin);
                scanf("%s",&nome);
                res2=inserir2(&B.raiz,k,nome);
                if (res2==0)
                    printf("\n\nERRO - O voto nao foi concluido\n");
                if (res2==1){
                    insere(nome,&ini);
                    printf("\n\nVoto efetuado com sucesso!");
                }
            }
        }
        else if (opcao==5) {
            printf("\nEntre com o titulo do eleitor que quer retirar o voto: ");
            scanf("%d",&k);
            res=buscar1(&A.raiz,k);
            if (res==0)
                printf("\n\nTitulo nao cadastrado\n");
            if (res==1){
                res2=remover2(&B.raiz,k,nome);
                if (res2==0)
                    printf("ERRO\n");
                if (res2==1)

                    removel(nome, &ini);
                    printf("\n\nVoto removido com sucesso!");
            }
        }
        else if (opcao==6) {
            imprima(&ini);
        }
        else if (opcao==7) {
            printf("\n\n Maior titulo que ja votou: %d",busca_maior2(&B.raiz));
        }
        else if (opcao==8) {
            printf("\n\n Menor titulo que ja votou: %d",busca_menor(&B.raiz));
        }
        else if (opcao==9) {
            printf("\n");
            imprimir1(&A.raiz);
        }
        else if (opcao==10) {
            printf("\n");
            imprimir2(&B.raiz);
        }
        else printf("\nOpcao invalida\n");

            printmenu();
            printf("Sua opcao: ");
            scanf("%d",&opcao);
        }
    printf("\n");
    printf("Titulos cadastrados: \t");
    imprimir1(&A.raiz);
    printf("\n\nVotos efetuados (eleitor/candidato): \t");
    imprimir2(&B.raiz);
    printf("\n");
    finalizar1(&A.raiz);
    finalizar2(&B.raiz);
    system("pause");

    return 0;
}
