#include <stdio.h>
#include <string.h>


struct cel {
        int votos;
        char nome[20];
        struct cel *prox;
};

typedef struct cel nol;

void imprima(nol *ini){
   nol *p;
   for (p = ini; p != NULL; p = p->prox)
      printf ("(%s / %d)\n",p->nome, p->votos);
    return;
}

nol *busca (char nome[20], nol *ini){
    nol *p;
    p = ini;
    while (p != NULL && strcmp(p->nome,nome)!=0){
        p = p->prox;
    }
    return p;
}

void insere (char nome[20], nol *p){

    if(busca(nome, &p)!=NULL){
        nol *aux;
        aux=busca(nome, &p);
        aux->votos++;
    }
    if(busca(nome,&p)==NULL){
        nol *nova = (nol*) malloc(sizeof(nol));
        nova->votos = 1;
        strcpy(nova->nome,nome);
        nova->prox = p->prox;
        p->prox = nova;
    }
    return;
}

void removel (char nome[20], nol *morta){

    nol *p;
    p=NULL;
    while (morta != NULL && strcmp(morta->nome,nome)!=0){
        p=morta;
        morta=morta->prox;
    }

    p->prox = morta->prox;
    free (morta);
    return;
}
