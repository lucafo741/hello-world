#include <stdio.h>
#include <string.h>
#include "ABB.h"

//fun��o para criar/inicializar a �rvore de busca bin�ria
void criar(ABB1 *A,ABB2 *B) {
     A->raiz=NULL;
     B->raiz=NULL;
}

//fun��o para finalizar �rvore de busca bin�ria; deve come�ar com p=raiz
void finalizar1(no1 **p) {
     if (*p!=NULL) {
        finalizar1(&(*p)->esq);
        finalizar1(&(*p)->dir);
        free(*p);
     }
}
void finalizar2(no2 **p) {
     if (*p!=NULL) {
        finalizar2(&(*p)->esq);
        finalizar2(&(*p)->dir);
        free(*p);
     }
}

//imprime os elementos da �rvore
void imprimir1(no1 **p) {
     if (*p!=NULL) {
        printf("%d, ",(*p)->info);
        if((*p)->esq!=NULL)
            imprimir1(&(*p)->esq);
        if((*p)->dir!=NULL)
            imprimir1(&(*p)->dir);
     }
     else printf("Nao ha titulos cadastrados.");
}
void imprimir2(no2 **p) {
     if (*p!=NULL) {
        printf("(%d, %s) ",(*p)->info.titulo, (*p)->info.candidato);

        if((*p)->esq!=NULL)
            imprimir2(&(*p)->esq);
        if((*p)->dir!=NULL)
            imprimir2(&(*p)->dir);
     }
     else printf("Nao ha nenhum voto computado.\n\n");
}

//fun��o de busca de um elemento na �rvore bin�ria de busca; deve come�ar com p=raiz
int buscar1(no1 **p, int x) {
    if (*p==NULL)
       return 0;
    else if (x<(*p)->info)
         return(buscar1(&(*p)->esq,x));
    else if (x>(*p)->info)
         return(buscar1(&(*p)->dir,x));
    else return 1;
}
int buscar2(no2 **p, int x) {
    if (*p==NULL)
       return 0;
    else if (x<(*p)->info.titulo)
         return(buscar2(&(*p)->esq,x));
    else if (x>(*p)->info.titulo)
         return(buscar2(&(*p)->dir,x));
    else return 1;
}

//fun��o de inser��o de um elemento na �rvore bin�ria de busca; deve come�ar com p=raiz
int inserir1(no1 **p, int x) {
     if (*p==NULL) {
        *p=(no1*) malloc(sizeof(no1));
        (*p)->info=x;
        (*p)->esq=NULL;
        (*p)->dir=NULL;
        return 1;
     }
     else if (x<(*p)->info)
          return(inserir1(&(*p)->esq,x));
     else if (x>(*p)->info)
          return(inserir1(&(*p)->dir,x));
     else return 0;
}
int inserir2(no2 **p, int x, char nome[20]) {

     int i;
     if (*p==NULL) {
        *p=(no2*) malloc(sizeof(no2));
        (*p)->info.titulo=x;
        strcpy((*p)->info.candidato,nome);
        (*p)->esq=NULL;
        (*p)->dir=NULL;
        return 1;
     }
     else if (x<(*p)->info.titulo)
          return(inserir2(&(*p)->esq,x,nome));
     else if (x>(*p)->info.titulo)
          return(inserir2(&(*p)->dir,x,nome));
     else return 0;
}

//fun��o que retorna o maior elemento de uma subarvore com raiz em p
int busca_maior1(no1 **p){
    no1 *aux, *back;

    aux=*p;
    back=*p;
    while ((*p)->dir!=NULL)
        *p=(*p)->dir;
    aux=*p;
    *p=back;
    return ((aux)->info);
}
int busca_maior2(no2 **p){
    no2 *aux, *back;

    aux=*p;
    back=*p;
    while ((*p)->dir!=NULL)
        *p=(*p)->dir;
    aux=*p;
    *p=back;
    return ((aux)->info.titulo);
}
int busca_menor(no2 **p){
    no2 *aux;
    aux=*p;
    while((aux)->esq!=NULL)
        *p=(*p)->esq;
    return ((*p)->info.titulo);
}

//fun��o que remove um elemento de uma �rvore
int remover1(no1 **p, int x) {
    no1 *aux;
    if (*p==NULL)
       return 0;
    else if (x<(*p)->info)
         return(remover1(&(*p)->esq,x));
    else if (x>(*p)->info)
         return(remover1(&(*p)->dir,x));
    else {
         //caso 1: o n� n�o tem filhos
         if (((*p)->esq==NULL) && ((*p)->dir==NULL)) {
            free(*p);
            *p=NULL;
            return 1;
         }
         //caso 2a: s� h� o filho direito
         else if ((*p)->esq==NULL) {
              aux=*p;
              *p=(*p)->dir;
              free(aux);
              return 1;
         }
         //caso 2b: s� h� o filho esquerdo
         else if ((*p)->dir==NULL) {
              aux=*p;
              *p=(*p)->esq;
              free(aux);
              return 1;
         }
         //caso 3: h� os dois filhos
         else {
              (*p)->info=busca_maior1((*p)->esq);
              return(remover1(&(*p)->esq,(*p)->info));
         }
    }
}
int remover2(no2 **p, int x, char nome[20]) {

    no2 *aux;
    if (*p==NULL)
       return 0;
    else if (x<(*p)->info.titulo)
         return(remover2(&(*p)->esq,x,nome));
    else if (x>(*p)->info.titulo)
         return(remover2(&(*p)->dir,x,nome));
    else {
         //caso 1: o n� n�o tem filhos
         strcpy(nome,(*p)->info.candidato);
         if (((*p)->esq==NULL) && ((*p)->dir==NULL)) {
            free(*p);
            *p=NULL;
            return 1;
         }
         //caso 2a: s� h� o filho direito
         else if ((*p)->esq==NULL) {
              aux=*p;
              *p=(*p)->dir;
              free(aux);
              return 1;
         }
         //caso 2b: s� h� o filho esquerdo
         else if ((*p)->dir==NULL) {
              aux=*p;
              *p=(*p)->esq;
              free(aux);
              return 1;
         }
         //caso 3: h� os dois filhos
         else {
              (*p)->info.titulo=busca_maior2((*p)->esq);
              return(remover2(&(*p)->esq,(*p)->info.titulo,nome));
         }
    }
}

