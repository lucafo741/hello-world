//declara��o do n� da �rvore
typedef int elem1;

typedef struct elem2{
    int titulo;
    char candidato[50];
} elem2;

typedef struct no1 {
    elem1 info;
    struct no1 *esq, *dir;
} no1;

typedef struct no2{
    elem2 info;
    struct no2 *esq, *dir;
} no2;

typedef struct {
    no1 *raiz;
} ABB1;

typedef struct {
    no2 *raiz;
} ABB2;

struct bloco {
    int votos;
    char nome[20];
    struct bloco *prox;
};

typedef struct bloco nol;

typedef struct lista{
    nol *ini;
    nol *fim;
}Lista;


//prot�tipos das fun��es
void criar(ABB1*,ABB2*);
void finalizar1(no1**);
void finalizar2(no2**);
void imprimir1(no1**);
void imprimir2(no2**);
int inserir1(no1**,int);
int inserir2(no2**,int,char[]);
int remover1(no1**,int);
int remover2(no2**,int,char[]);
int buscar1(no1**,int);
int buscar2(no2**,int);
