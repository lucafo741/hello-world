#include <stdio.h>
#include <string.h>

typedef struct User{
    char id[50];
    char nome[50];
    int n;
}user;

int adicionauser(user *v,char Nome[50],char Id[50],int *N){
    int i;
    for(i=0;i<*N;i++){
        if(strcmp(v[i].nome,Nome)){
            return i;
        }
    }
    strcpy(v[*N].nome,Nome);
    strcpy(v[*N].id,Id);
    v[*N].n=*N;
    *N++;
    return *N-1;
}

void leramigo(int **m,user *v,int *N,int quem){
    char coisa1[50],coisa2[50];
    int i;
    while(getchar()!=':'){}
    while(getchar()!='"'){}
    scanf("%[^\"]",coisa1);
    while(getchar()!=':'){}
    while(getchar()!='"'){}
    scanf("%[^\"]",coisa2);

    m[quem][adicionauser(v,coisa1,coisa2,N)]=1;

    return;
}
void lerusuario(int **m, char *v,int *N){
    char coisa1[50],coisa2[50],a;
    int i;
    while(getchar()!=':'){}
    while(getchar()!='"'){}
    scanf("%[^\"]",coisa1);
    while(getchar()!=':'){}
    while(getchar()!='"'){}
    scanf("%[^\"]",coisa2);

    i=adicionauser(v,coisa2,coisa1,N);

    do{
        while(getchar()!='{'){}
        leramigo(m,v,N,i);
        do{
            a=getchar();
        }while(a!=',' && a!=']');
        if(a==']')
            return;

    }while(1);
}

int main(){
    char a;
    user usuarios[200];
    int matriz[200][200];
    int i,j,N=0;
    for(i=0;i<200;i++)
        for(j=0;j<200;j++)
            matriz[i][j]=0;

    do{
        lerusuario(matriz,usuarios,N);
        do{
            a=getchar();
        }while(a!=',' && a!=']');
        if(a==']')
            return;
    }while(1);
}
